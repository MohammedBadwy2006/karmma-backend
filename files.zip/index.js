require("dotenv").config();
const express = require("express");
const cors = require("cors");
const Anthropic = require("@anthropic-ai/sdk");

const app = express();
app.use(cors());
app.use(express.json());

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

const SYSTEM_PROMPT = `إنت مرشد سياحي متخصص في الآثار المصرية.
- رد على أسئلة السياح بدقة عن المعابد، المقابر، الأهرامات، المتاحف، والتاريخ الفرعوني.
- لو السائل بيكتب بالإنجليزي أو أي لغة تانية، رد بنفس اللغة اللي كتب بيها.
- لو مش متأكد من معلومة، قول كده بوضوح، ماتخترعش معلومات.
- خلي الردود مختصرة وممتعة، مناسبة لسائح مش لباحث أكاديمي.`;

// Health check - عشان تتأكد إن السيرفر شغال
app.get("/", (req, res) => {
  res.json({ status: "ok", message: "Karmma backend is running" });
});

app.post("/chat", async (req, res) => {
  try {
    const { message, history } = req.body;

    if (!message || typeof message !== "string") {
      return res.status(400).json({ error: "message field is required" });
    }

    // history جاي من فلاتر بصيغة [{role, content}], نحولها لصيغة الـ API
    const messages = [
      ...(Array.isArray(history)
        ? history.map((m) => ({ role: m.role, content: m.content }))
        : []),
      { role: "user", content: message },
    ];

    const response = await anthropic.messages.create({
      model: "claude-sonnet-5",
      max_tokens: 1024,
      system: SYSTEM_PROMPT,
      messages: messages,
    });

    const reply = response.content[0].text;
    res.json({ reply });
  } catch (error) {
    console.error("Anthropic API error:", error);
    res.status(500).json({ error: "حصل خطأ في السيرفر", details: error.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, "0.0.0.0", () => {
  console.log(`Server running on http://0.0.0.0:${PORT}`);
});
